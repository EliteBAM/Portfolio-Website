using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateMapGeometry : MonoBehaviour
{
    public GenerationDataSO data;

    MapGenerator generator;

    public bool useMat = false;

    public Texture2D Block_Tex;
    public Material Block_Mat;

    public int Block_Size = 10;
    public int Height_Multiplier = 15;

    // Start is called before the first frame update
    void Start()
    {
        
        generator = new MapGenerator(100, 100, data);
        generator.seed = 212937372;

        generator.GenerateMap();
        generator.GenerateBiomes();
        generator.GenerateWorld();

        GenerateTerrain();
    }

    void GenerateTerrain()
    {
        int offsetX = 0;
        int offsetY;

        for(int i = generator.map.GetLength(0) - 1; i >= 0; i--)
        {
            offsetX += Block_Size;
            offsetY = 0;
            for(int j = generator.map.GetLength(1) - 1; j >= 0; j--)
            {
                GenerateBlock(offsetX, offsetY, generator.map[i, j].biome.material, generator.map, i, j);
                offsetY += Block_Size;
            }
        }
    }

    void GenerateBlock (int currentX, int currentZ, Material blockMat, WorldNode[,] map, int i, int j)
    {
        Mesh terrain = new Mesh();
        terrain.vertices = new Vector3[] {  new Vector3(currentX, Height_Multiplier * map[i, j].height_BotLeft /*bottom left*/, currentZ),
                                            new Vector3(currentX, Height_Multiplier * map[i, j].height_TopLeft /*top left*/, currentZ + Block_Size),
                                            new Vector3(currentX + Block_Size, Height_Multiplier * map[i, j].height_BotRight /*bottom right*/, currentZ),
                                            new Vector3(currentX + Block_Size, Height_Multiplier * map[i, j].height_TopRight /*top right*/, currentZ + Block_Size) 
                                         };

        terrain.uv = new Vector2[] { new Vector2(0, 0), new Vector2(0, 1), new Vector2(1, 0), new Vector2(1, 1) };
        terrain.triangles = new int[] { 0, 1, 2, 2, 1, 3 };
        terrain.RecalculateNormals();

        GameObject newGeometry = new GameObject();
        newGeometry.name = "Terrain";
        MeshRenderer renderer = newGeometry.AddComponent<MeshRenderer>();
        MeshFilter filter = newGeometry.AddComponent<MeshFilter>();
        filter.mesh = terrain;
        if (!useMat)
        {
            Material mat = new Material(Shader.Find("Diffuse"));
            mat.mainTexture = Block_Tex;
            renderer.material = mat;
        }
        else
            renderer.material = blockMat;

    }

    // Update is called once per frame
    //asoidhoasihdoiashdo 
    void Update()
    {
        
    }
}
