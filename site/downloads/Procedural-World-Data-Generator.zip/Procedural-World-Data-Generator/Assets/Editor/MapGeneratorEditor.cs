using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor (typeof(MapGenerator))]
public class MapGeneratorEditor : Editor
{
    public override void OnInspectorGUI()
    {
        MapGenerator mapGen = (MapGenerator)target;

        if (DrawDefaultInspector())
        {
            if(mapGen.autoUpdate)
            {
                mapGen.GenerateMap();
                //mapGen.GenerateBiomes();
                //mapGen.GenerateWorld();
            }
        }

        if (GUILayout.Button ("Generate Perlin"))
        {
            mapGen.GenerateMap();
        }
        if (GUILayout.Button("Generate Voronoi"))
        {
            mapGen.GenerateBiomes();
        }
        if (GUILayout.Button("Generate World"))
        {
            mapGen.GenerateWorld();
        }
    }
}
