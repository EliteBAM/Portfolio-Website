using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class VoronoiNoise
{
    public static float[] biomeIdList;
    public static float[,] GenerateVoronoiNoise(int mapWidth, int mapHeight, int regions, BiomeType[] biomes, bool minKowskiDistance, int p)
    {
        float[,] noiseMap = new float[mapWidth, mapHeight];

        Vector2Int[] centroids = new Vector2Int[regions];
        float[] regionCount = new float[regions];

        Debug.Log("biomes length: " + biomes.Length);
        //biome implementation varaibles
        biomeIdList = new float[biomes.Length];

        //create biome IDs
        float step = 1f / biomes.Length;
        float init = 0f;
        for(int i = 0; i < biomes.Length; i++)
        {
            biomeIdList[i] = init + step;

            //saves the biome id in the biome dataset for retrieval later
            biomes[i].id = biomeIdList[i];

            init = biomeIdList[i];
        }

        //Randomly generate coordinates for each centroid, then randomly set a gradient value between 0 and 1 for each region.
        centroids[centroids.Length - 1] = new Vector2Int(mapWidth / 2, mapHeight / 2);
        regionCount[regionCount.Length - 1] = biomeIdList[0];
        for(int i = 0; i < regions-1; i++)
        {
            centroids[i] = new Vector2Int(Random.Range(0, mapWidth), Random.Range(0, mapHeight));

            //Randomly choose which biome ID to assign to the next region
            float randRegion = biomeIdList[Random.Range(0, biomeIdList.Length)];
            regionCount[i] = randRegion;
        }

        for(int x = 0; x < mapWidth; x++)
        {
            for(int y = 0; y < mapHeight; y++)
            {
                //int i = x * mapWidth + y;
                noiseMap[x, y] = regionCount[GetClosestCentroidIndex(new Vector2Int(x, y), centroids, minKowskiDistance, p)];
            }
        }

        return noiseMap;
    }

    public static int GetClosestCentroidIndex(Vector2Int pixelPos, Vector2Int[] centroids, bool minKowski, int p)
    {
        float smallestDst = float.MaxValue;
        int index = 0;
        for(int i = 0; i < centroids.Length; i++)
        {
            float currentDst;

            if (!minKowski)
                currentDst = Vector2.Distance(pixelPos, centroids[i]);
            else
                currentDst = MinkowskiDistance(pixelPos, centroids[i], p);

            if (currentDst < smallestDst)
            {
                smallestDst = currentDst;
                index = i;
            }
        }
        return index;
    }

    public static float MinkowskiDistance(Vector2 p1, Vector2 p2, int p)
    {
        float distance = 0f;

        for(int i = 0; i < 2; i++)
        {
            distance = distance + Mathf.Pow(Mathf.Abs(p1[i] - p2[i]), p);
        }

        return distance;
    }
}
