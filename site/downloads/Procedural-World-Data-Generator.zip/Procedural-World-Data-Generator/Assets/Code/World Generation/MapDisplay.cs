using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapDisplay : MonoBehaviour
{
    public Renderer perlinRenderer;
    public Renderer voronoiRenderer;
    public Renderer worldRenderer;

    public void DrawPerlinTexture(Texture2D texture)
    {
        perlinRenderer.sharedMaterial.mainTexture = texture;
    }

    public void DrawVoronoiTexture(Texture2D texture)
    {
        voronoiRenderer.sharedMaterial.mainTexture = texture;
    }

    public void DrawWorldTexture(Texture2D texture)
    {
        worldRenderer.sharedMaterial.mainTexture = texture;
    }
}
