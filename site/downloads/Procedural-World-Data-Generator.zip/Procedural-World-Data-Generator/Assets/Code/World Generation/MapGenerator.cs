using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapGenerator : MonoBehaviour
{
    [Header("World Settings")]
    public int mapWidth;
    public int mapHeight;

    public GenerationDataSO data;

    [Range(0, 1)]
    public float deepWaterLevel = 0.4f;
    public Color deepWaterColor = new Color(1f/255f, 155f/255f, 245f/255f);
    [Range(0,1)]
    public float oceanLevel = 0.47f;
    public Color oceanColor = new Color(0, 186f/255f, 255/255);
    [Range(0, 1)]
    public float beachLevel = 0.5f;
    public Color beachColor = new Color(255/255, 226f/255f, 122/255f);
    [Range(0, 1)]
    public float landLevel = 1f;
    public Color landColor = new Color(0, 188f/255f, 56/255f);

    [Header("Perlin Noise Settings")]
    public float noiseScale;

    public int octaves;

    [Range(0, 1)]
    public float persistance;
    public float lacunarity;

    public int seed;
    public Vector2Int offset;

    public enum DrawMode { NoiseMap, ColorMap };
    public DrawMode perlinDrawMode;

    [Header("Voronoi Noise Settings")]
    public int centroids;
    public int biomeCount;
    public bool useMinkowskiDistance;
    public int pValue;

    public DrawMode voronoiDrawMode;
    public BiomeType[] biomeTypes;

    [Header("Generation Settings")]
    public bool autoUpdate;

    //noise map arrays
    private float[,] noiseMap;
    private float[,] voronoiMap;

    //world map public for debugging only
    [SerializeField]
    public WorldNode[,] map;

    public MapGenerator(int width, int height, GenerationDataSO data)
    {
        mapWidth = width;
        mapHeight = height;
        this.data = data;

        //Set Generation Defaults
        //Perlin Defaults
        noiseScale = 224.8f;
        octaves = 4;
        persistance = 0.43f;
        lacunarity = 2.66f;
        seed = 21;
        offset = new Vector2Int(13, 6);

        perlinDrawMode = DrawMode.ColorMap;
        //Voronoi Defaults
        centroids = 30;
        biomeCount = 1;
        if(data != null)
            biomeTypes = this.data.biomes;
        useMinkowskiDistance = true;
        pValue = 4;

        //new Color(0, 188, 56)
        //new Color(255, 226, 122)

        voronoiDrawMode = DrawMode.ColorMap;
    }

    public void GenerateMap()
    {
        noiseMap = PerlinNoise.GenerateNoiseMap(mapWidth, mapHeight, seed, noiseScale, octaves, persistance, lacunarity, offset);

        Color[] colorMap = new Color[mapWidth * mapHeight];
        for (int y = 0; y < mapHeight; y++)
        {
            for (int x = 0; x < mapWidth; x++)
            {
                float currentHeight = noiseMap[x, y];
                if(currentHeight <= deepWaterLevel)
                {
                    colorMap[y * mapWidth + x] = deepWaterColor;
                }
                else if (currentHeight <= oceanLevel)
                {
                    colorMap[y * mapWidth + x] = oceanColor;
                }
                else if (currentHeight <= beachLevel)
                {
                    colorMap[y * mapWidth + x] = beachColor;
                }
                else if (currentHeight <= landLevel)
                {
                    colorMap[y * mapWidth + x] = landColor;
                }
            }
        }

        MapDisplay display = FindObjectOfType<MapDisplay>();
        if(perlinDrawMode == DrawMode.NoiseMap)
            display.DrawPerlinTexture(TextureGenerator.TextureFromNoiseMap(noiseMap));
        else if(perlinDrawMode == DrawMode.ColorMap)
            display.DrawPerlinTexture(TextureGenerator.TextureFromColorMap(colorMap, mapWidth, mapHeight));
    }

    public void GenerateBiomes()
    {
        if (data != null)
            biomeTypes = this.data.biomes;

        voronoiMap = VoronoiNoise.GenerateVoronoiNoise(mapWidth, mapHeight, centroids, biomeTypes, useMinkowskiDistance, pValue);

        Color[] colorMap = new Color[mapWidth * mapHeight];
        for (int y = 0; y < mapHeight; y++)
        {
            for (int x = 0; x < mapWidth; x++)
            {
                float currentPixelId = voronoiMap[x, y];
                for (int i = 0; i < biomeTypes.Length; i++)
                {
                    if (currentPixelId == VoronoiNoise.biomeIdList[i])
                    {
                        biomeTypes[i].id = currentPixelId;
                        colorMap[y * mapWidth + x] = biomeTypes[i].color;
                        break;
                    }
                }
            }
        }

        MapDisplay display = FindObjectOfType<MapDisplay>();
        if (voronoiDrawMode == DrawMode.NoiseMap)
            display.DrawVoronoiTexture(TextureGenerator.TextureFromNoiseMap(voronoiMap));
        else if (voronoiDrawMode == DrawMode.ColorMap)
            display.DrawVoronoiTexture(TextureGenerator.TextureFromColorMap(colorMap, mapWidth, mapHeight));
    }

    public void GenerateWorld()
    {
        void GetHeightValues(int x, int y, out float h_bottomleft, out float h_topleft, out float h_topRight, out float h_bottomRight)
        {
            int denominator = 1;

            //get height 1
            h_bottomleft = noiseMap[x, y];

            if (y + 1 < mapHeight)
            {
                h_bottomleft += noiseMap[x, y + 1];
                denominator++;
            }

            if (y + 1 < mapHeight && x + 1 < mapWidth)
            {
                h_bottomleft += noiseMap[x + 1, y + 1];
                denominator++;
            }
            
            if (x + 1 < mapWidth)
            {
                h_bottomleft += noiseMap[x + 1, y];
                denominator++;
            }
            
            h_bottomleft = h_bottomleft / denominator;
            denominator = 1;

            //get height 2
            h_topleft = noiseMap[x, y];

            if (x + 1 < mapWidth)
            {
                h_topleft += noiseMap[x + 1, y];
                denominator++;
            }

            if (y - 1 >= 0 && x + 1 < mapWidth)
            {
                h_topleft += noiseMap[x + 1, y - 1];
                denominator++;
            }

            if (y - 1 >= 0)
            {
                h_topleft += noiseMap[x, y - 1];
                denominator++;
            }

            h_topleft = h_topleft / denominator;
            denominator = 1;

            //get height 3
            h_topRight = noiseMap[x, y];

            if (y - 1 >= 0)
            {
                h_topRight += noiseMap[x, y - 1];
                denominator++;
            }

            if (y - 1 >= 0 && x - 1 >= 0)
            {
                h_topRight += noiseMap[x - 1, y - 1];
                denominator++;
            }

            if (x - 1 >= 0)
            {
                h_topRight += noiseMap[x - 1, y];
                denominator++;
            }

            h_topRight = h_topRight / denominator;
            denominator = 1;

            //get height 4
            h_bottomRight = noiseMap[x, y];

            if (x - 1 >= 0)
            {
                h_bottomRight += noiseMap[x - 1, y];
                denominator++;
            }

            if (x - 1 >= 0 && y + 1 < mapHeight)
            {
                h_bottomRight += noiseMap[x - 1, y + 1];
                denominator++;
            }

            if (y + 1 < mapHeight)
            {
                h_bottomRight += noiseMap[x, y + 1];
                denominator++;
            }

            h_bottomRight = h_bottomRight / denominator;
            denominator = 1;

        }

        map = new WorldNode[mapWidth, mapHeight];

        if(noiseMap != null && voronoiMap != null)
        {
            for (int y = 0; y < mapHeight; y++)
            {
                for (int x = 0; x < mapWidth; x++)
                {
                    bool isLand;
                    bool isSand;
                    float biomeID;

                    float height_BotLeft;
                    float height_TopLeft;
                    float height_TopRight;
                    float height_BotRight;
                    GetHeightValues(x, y, out height_BotLeft, out height_TopLeft, out height_TopRight, out height_BotRight);

                    if (noiseMap[x, y] > oceanLevel)
                    {
                        isLand = true;
                        if (noiseMap[x, y] > oceanLevel && noiseMap[x, y] <= beachLevel)
                            isSand = true;
                        else
                            isSand = false;

                        biomeID = voronoiMap[x, y];

                        
                        map[x, y] = new WorldNode(data.GetBiome(biomeID), isLand, isSand, noiseMap[x, y], height_BotLeft, height_TopLeft, height_TopRight, height_BotRight);
                    }
                    else
                    {
                        isLand = false;
                        isSand = false;
                        biomeID = 0;

                        map[x, y] = new WorldNode(data.GetBiome(biomeID), isLand, isSand, noiseMap[x, y], height_BotLeft, height_TopLeft, height_TopRight, height_BotRight);
                    }
                }
            }
        }
        else
        {
            Debug.LogAssertion("Generate Noise Maps Before Generating World");
        }

        Color[] colorMap = new Color[mapWidth * mapHeight];
        for (int y = 0; y < mapHeight; y++)
        {
            for (int x = 0; x < mapWidth; x++)
            {
                WorldNode currentNode = map[x, y];
                if(currentNode.isLand)
                {
                    for (int i = 0; i < VoronoiNoise.biomeIdList.Length; i++)
                    {
                        if (currentNode.biome.id == VoronoiNoise.biomeIdList[i])
                        {
                            biomeTypes[i].id = currentNode.biome.id;
                            if(currentNode.isSand)
                                colorMap[y * mapWidth + x] = biomeTypes[i].beachColor;
                            else
                                colorMap[y * mapWidth + x] = biomeTypes[i].color;
                        }
                    }
                }
                else 
                {
                    if(noiseMap[x, y] <= 0.4)
                        colorMap[y * mapWidth + x] = deepWaterColor;
                    else
                        colorMap[y * mapWidth + x] = oceanColor;
                }
            }
        }
        MapDisplay display = FindObjectOfType<MapDisplay>();
        display.DrawWorldTexture(TextureGenerator.TextureFromColorMap(colorMap, mapWidth, mapHeight));
    }

    private void OnValidate()
    {
        if (mapWidth < 1)
            mapWidth = 1;
        if (mapHeight < 1)
            mapHeight = 1;
        if (lacunarity < 1)
            lacunarity = 1;
        if (octaves < 0)
            octaves = 0;
    }
}


[System.Serializable]
public struct BiomeType
{
    public string name;
    public float id;
    public Material material;
    public Color color;
    public Color beachColor;

    public BiomeType(string name, Color color, Color beachColor)
    {
        this.name = name;
        this.color = color;
        id = 0;
        material = null;
        this.beachColor = beachColor;
    }
}