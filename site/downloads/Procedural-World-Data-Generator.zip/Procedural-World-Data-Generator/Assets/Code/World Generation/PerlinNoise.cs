using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PerlinNoise
{
    //Create a node class
    //Create a 2D node array of the same dimensinos as the Perlin noise
    //Create a height float value in the node class. Assign this value corresponding to the NoiseMap data for each node
    //Create a land/water ID variable in the node class. Use region list height data to set each node as land or water based on their height.
    //Create a Sand/Shallow Water ID variable in the node class. Use region list height data to further ID the nodes as sand or shallow water.
    //Create a Voronoi noise algorithm implementation that is set to create a voronoi map of equivalent size (resolution) as the perlin map.
    //Set set the Voronoi function to generate as many unique biomes as desired, as of now only 4.
    //Give each biome a corresponding color and int value (greater than zero).
    //Enable this Voronoi map to be outputted to a textured plane for tweaking/debugging purposes
    //Now go back and create a Voronoi biome int value in the node class. Cycle through all the nodes.
        //For nodes ID'd as water, leave the value set to zero. For Land nodes, set the biome value to its corresponding voronoi map value.
    //For debugging purposes, create a final Texture generator to generate a representation of the final map based on the node array data.
    //Now the world generation system should be complete. You may now take the node data and translate it into a final 3D tile-map game world.
    //... and use the texture debuggers to tweak the generation system to perfection.
    //You should end up with three debug textures plus the final world data. Perlin debug, Voronoi debug, and the final world map debug.

    //STRETCH GOALS
    //If possible, use distortion perlin noise to make the borders between Voronoi cells look more fluid
    //If possible, make is so that the edges of the map generation area are always water, leaving only complete islands in the game world
    //If possible, blend textures between voronoi cells to make biome transitions look smooth
        //Alternatively, loop through each node in the node array and have each node check the biome identity of its neighbors.
            //Use this data to set an appropriate biome transition texture. This may get tricky and would require a huge transitions tileset


    public static float[,] GenerateNoiseMap(int mapWidth, int mapHeight, int seed, float scale, int octaves, float persistance, float lacunarity, Vector2Int offset)
    {
        float[,] noiseMap = new float[mapWidth, mapHeight];

        System.Random prng = new System.Random (seed);
        Vector2[] octaveOffsets = new Vector2[octaves];
        for (int i = 0; i < octaves; i++)
        {
            float offsetX = prng.Next(-100000, 100000) + offset.x/scale;
            float offsetY = prng.Next(-100000, 100000) + offset.y/scale;
            octaveOffsets[i] = new Vector2(offsetX, offsetY);
        }

        if (scale <= 0)
            scale = 0.0001f;

        float maxNoiseHeight = 1.5f; //float.MinValue
        float minNoiseHeight = 0f;  //float.MaxValue

        float halfWidth = mapWidth / 2f;
        float halfHeight = mapHeight / 2f;

        for(int y = 0; y < mapHeight; y++)
        {
            for(int x = 0; x < mapWidth; x++)
            {

                float amplitude = 1;
                float frequency = 1;
                float noiseHeight = 0;

                for(int i = 0; i < octaves; i++)
                {
                    float sampleX = (x - halfWidth) / scale * frequency + octaveOffsets[i].x * frequency;
                    float sampleY = (y - halfHeight) / scale * frequency + octaveOffsets[i].y * frequency;

                    float perlinValue = Mathf.PerlinNoise(sampleX, sampleY);
                    noiseHeight += perlinValue * amplitude;

                    amplitude *= persistance;
                    frequency *= lacunarity;
                }

                /*if (noiseHeight > maxNoiseHeight)
                {
                    maxNoiseHeight = noiseHeight;
                }
                else if (noiseHeight < minNoiseHeight)
                {
                    minNoiseHeight = noiseHeight;
                }*/
                noiseMap[x, y] = noiseHeight;
            }
        }

        for (int y = 0; y < mapHeight; y++)
        {
            for (int x = 0; x < mapWidth; x++)
            {
                noiseMap[x, y] = Mathf.InverseLerp(minNoiseHeight, maxNoiseHeight, noiseMap[x, y]);
            }
        }

        return noiseMap;
    }
}
