using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldNode
{

    public BiomeType biome;
    public bool isLand;
    public bool isSand;

    public float normalizedHeight;

    public float height_BotLeft;
    public float height_TopLeft;
    public float height_TopRight;
    public float height_BotRight;

    public WorldNode(BiomeType biome, bool isLand, bool isSand, float normalizedHeight, float height_BotLeft, float height_TopLeft, float height_TopRight, float height_BotRight)
    {
        this.biome = biome;
        this.isLand = isLand;
        this.isSand = isSand;
        this.normalizedHeight = normalizedHeight;

        this.height_BotLeft = height_BotLeft;
        this.height_TopLeft = height_TopLeft;
        this.height_TopRight = height_TopRight;
        this.height_BotRight = height_BotRight;
    }

}
