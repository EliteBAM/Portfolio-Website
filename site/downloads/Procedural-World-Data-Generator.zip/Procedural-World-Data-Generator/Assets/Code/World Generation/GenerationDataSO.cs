using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Generation Profile", menuName = "World Generator/Create new Biome Profile")]
public class GenerationDataSO : ScriptableObject
{

    public BiomeType[] biomes;

    public BiomeType water;

    public BiomeType GetBiome(float id)
    {

        for(int i = 0; i < biomes.Length; i++)
        {
            if (biomes[i].id == id)
                return biomes[i];
        }

        //if biome is not found
        return water;
    }

}
